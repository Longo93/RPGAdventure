from classes.game import Person, bcolors
from classes.magic import Spell
from classes.inventory import Item


# Create black magic
fire = Spell("Fire", 10, 130, "Black")
lightning = Spell("Lightning", 10, 130, "Black")
frost = Spell("Frost", 10, 130, "Black")
meteor = Spell("Meteor", 15, 150, "Black")
quake = Spell("Quake", 20, 260, "Black")

# Create light magic
cure = Spell("Cure", 12, 120, "White")
cure_II = Spell("Strong Cure", 18, 150, "White")

# Create some items
potion = Item("Potion", "potion", "Heals for 50 HP", 50)
strong_potion = Item("Strong Potion", "potion", "Heals for 100 HP", 100)
super_potion = Item("Super Potion", "potion", "Heals for 500 HP", 500)
elixir_of_the_one = Item("Elixir of the One", "elixir", "Fully restores HP/MP of one party member", 9999)
elixir_of_the_many = Item("Elixir of the Many", "elixir", "Fully restores HP/MP of the entire party", 9999)

grenade = Item("Grenade", "attack", "Deals 500 Damage", 500)

# List player spells
player_spells = [fire, lightning, frost, meteor, quake, cure, cure_II]
player_items = [{"item": potion, "quantity": 15}, {"item": strong_potion, "quantity": 5}, {"item": super_potion, "quantity": 2},
                {"item": elixir_of_the_one, "quantity": 1}, {"item": elixir_of_the_many, "quantity": 2}, {"item": grenade, "quantity": 5}]

player = Person(500, 100, 50, 40, player_spells, player_items)
enemy = Person(1200, 65, 45, 25, [], [])

running = True
i = 0

print(bcolors.FAIL + bcolors.BOLD + "AN ENEMY ATTACKS!", bcolors.ENDC)

while running:
    print("==========================")
    player.choose_action()
    choice = input("What will you do?\t")
    index = int(choice) - 1

    # ATTACKING THE ENEMY
    if index == 0:
        dmg = player.generate_damage()
        enemy.take_damage(dmg)
        print("You attacked for", dmg, "points of damage.")

    # CHOOSING A SPELL
    elif index == 1:
        player.choose_magic()
        magic_choice = int(input("Choose your spell: ")) - 1

        # IF PLAYER PRESSES 0 THEY'LL GO BACK A MENU
        if magic_choice == -1:
            continue

        spell = player.magic[magic_choice]
        magic_dmg = spell.generate_damage()

        current_mp = player.get_mp()

        if spell.cost > current_mp:
            print(bcolors.FAIL + "\nNot Enough MP\n" + bcolors.ENDC)
            continue
        player.reduce_mp(spell.cost)

        # DIFFERENT EFFECTS FOR DIFFERENT SPELL TYPES
        if spell.type == "White":
            player.heal(magic_dmg)
            print(bcolors.OKBLUE + "\n", spell.name, " heals you for:", str(magic_dmg), "HP", bcolors.ENDC)
        elif spell.type == "Black":
            enemy.take_damage(magic_dmg)
            print(bcolors.OKBLUE + "\n", spell.name + " deals", str(magic_dmg), "points of damage" + bcolors.ENDC)

    # PLAYER WANTS TO USE AN ITEM
    elif index == 2:
        player.choose_item()
        item_choice = int(input("Choose your Item: ")) - 1

        # IF PLAYER PRESSES 0 THEY'LL GO BACK A MENU
        if item_choice == -1:
            continue

        item = player.items[item_choice]["item"]

        if player.items[item_choice]["quantity"] == 0:
            print(bcolors.FAIL, "\n" + "You reach into your pocket and find that you have'nt any", "'" + item.name + "'", "left to use." + bcolors.ENDC)
            continue

        player.items[item_choice]["quantity"] -= 1


        # ITEM EFFECTS
        if item.type == "potion":
            player.heal(item.prop)
            print(bcolors.OKGREEN, "\n", item.name, "heals player for", str(item.prop), "HP", bcolors.ENDC)
        elif item.type == "elixir":
            player.hp = player.maxhp
            player.mp = player.maxmp
            print(bcolors.OKGREEN, "\nHP and MP have been fully replenished for this Player", bcolors.ENDC)
        elif item.type == "attack":
            enemy.take_damage(item.prop)
            print( bcolors.FAIL, "\n", item.name, "has dealt", str(item.prop), "damage to the enemy", bcolors.ENDC)
    enemy_choice = 1

    enemy_dmg = enemy.generate_damage()
    player.take_damage(enemy_dmg)
    print("Enemy attacks for", enemy_dmg)

    print("---------------------")
    print("Enemy hp:", bcolors.FAIL + str(enemy.get_hp()) + "/" + str(enemy.get_max_hp()) + bcolors.ENDC)

    print("Your HP:", bcolors.OKGREEN + str(player.get_hp()) + "/" + str(player.get_max_hp()) + bcolors.ENDC)
    print("Your MP", bcolors.OKBLUE + str(player.get_mp()) + "/" + str(player.get_max_mp()) + bcolors.ENDC)

    if enemy.get_hp() == 0:
        print(bcolors.OKGREEN + "YOU WIN!" + bcolors.ENDC)
        running = False
    elif player.get_hp() == 0:
        print(bcolors.FAIL + "You have died.\nGame Over." + bcolors.ENDC)
        running = False
